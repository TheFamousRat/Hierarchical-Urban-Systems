# Transformer le fichier d'origine en .csv
from pathlib import Path
import re
import csv
from typing import Any
import tqdm


CodeCommune = str

src_folder = Path(
    "/home/thefamousrat/Documents/Cartographie/Italie/data/flux/MATRICE PENDOLARISMO 2011/"
)
src_file = src_folder / "matrix_pendo2011_10112014.txt"
dst_file = src_folder / "flux_communes_italiennes.csv"

fieldnames = [
    "Record type",
    "Residence type",
    "Province of residence",
    "Municipality of residence",
    "Gender",
    "Reason for moving",
    "Place of study or work",
    "Usual province of study or work",
    "Usual municipality of study or work",
    "Foreign country of study or work",
    "Means",
    "Time out",
    "Time spent",
    "Estimated number of individuals",
    "Number of individuals",
]
with open(dst_file, "w") as f_out:
    writer = csv.DictWriter(f=f_out, fieldnames=fieldnames)
    writer.writeheader()
    with open(src_file, "r") as f_in:
        for line in tqdm.tqdm(f_in.readlines()):
            line_values = re.findall(pattern=r"(\S+)\s+", string=line)

            row_dict: dict[str, Any] = {}
            for field_name, field_value in zip(fieldnames, line_values):
                if field_name in ["Stima numero di individui", "Numero di individui"]:
                    if field_value == "ND":
                        field_value = None
                    else:
                        field_value = int(float(field_value))
                if field_value == "+":
                    field_value = None

                row_dict[field_name] = field_value

            writer.writerow(rowdict=row_dict)
